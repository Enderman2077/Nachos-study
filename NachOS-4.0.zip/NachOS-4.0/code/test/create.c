#include "syscall.h"
int main(){
    int result;
    result=Create("result2.txt");
    Halt();
    /* not reached */
}
